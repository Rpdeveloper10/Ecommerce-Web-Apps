var express = require('express'); //require express Module....
var bodyParser = require('body-parser'); //require body-parser module.....
var mysql = require('mysql'); // require mysql module......

/*Express use in app...........*/
var app = express();

//###### Express Validator...............
var expressValidator = require('express-validator')
app.use(expressValidator());

// flash and cookie parser.............
var flash = require('express-flash')
var cookieParser = require('cookie-parser');
var session = require('express-session');
app.use(cookieParser('keyboard cat'))
app.use(session({ 
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }
}))
app.use(session({secret:"secretpass123456",resave: false, saveUninitialized: true}));
app.use(flash());

// require express connction...........
var myConnection = require('express-myconnection'); 
var config = require('./config');
var dbconn = {
    host: config.database.host,
    user: config.database.user,
    password: config.database.password,
    database: config.database.db
}

//use express-myconnection in app........
app.use(myConnection(mysql, dbconn, 'pool')); 

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));
 
// parse application/json...........
app.use(bodyParser.json());

// user for public/image/image.jpg........
var publicDir = require('path').join(__dirname,'/public');
app.use(express.static(publicDir));

//#### setting up the templating view engine........
app.set('view engine', 'ejs');

var indexRouter = require('./routes/index');
var adminRouter = require('./routes/admin');

app.use('/', indexRouter);
app.use('/admin', adminRouter);

app.listen(3000, function(req, res){
   console.log('Listen to Port 3000');
});