var config = {
	database: {
      host: 'localhost',
      user: 'root',
      password: '',
      db: 'lelojee'
    }  
  };

module.exports = config;
