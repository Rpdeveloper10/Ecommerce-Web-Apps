var express = require('express');
var authentication_mdl = require('./middlewares/authentication');
var app = express();
var session_store; // store session value

//********** Get Login Form ..............................
app.get('/login', function(req, res){
  req.flash('msg_error',  ""); 
    if(!req.session.user_id) {
     res.render("admin/login",{
      title:"Admin Login Page",
      msg_error:'',
      msg:'',
      user_id:'',
      password:''
     });
   }else{
   //res.redirect(301, '/');
   res.render("admin/login",{
    title:" Admin Login Page",
    msg_error:'',
    msg:'',
    user_id:'',
    password:''
  });
  }
});

//********* Login using Post Method.................. 
app.post('/login', function(req,res){
	session_store=req.session;
      if(!session_store){
         res.redirect('/admin/login'); 
      }else{
         console.log(req.body);
         //console.log('Ratnesh');
            req.assert('user_id', 'Please enter your User id').notEmpty();
            //req.assert('txtEmail', 'Email not valid').isEmail();
            req.assert('password', 'Please enter your password').notEmpty();
      var errors = req.validationErrors();
            user_id = req.sanitize( 'user_id' ).escape().trim(); 
            password = req.sanitize( 'password' ).escape().trim();
   if (!errors) {
      //app.getConnection(function(err,connection){
      req.getConnection(function(error, conn) {
      conn.query('select * from users where user_id="'+user_id+'" and password="'+password+'"',function(err,rows)
      {
        if(err)
        {
          var errornya  = ("Error Selecting : %s ",err.code );  
          console.log(err.code);
          req.flash('msg_error', errornya); 
          res.locals.messages = req.flash();
          res.redirect('/admin/login'); 
        }else
        { 
          if(rows.length >0)
          {
            req.session.user_id = req.body.user_id;
            console.log('Logged In Successfully');
            session_store.is_login = true;
            //console.log(req.session.email);
            //console.log(rows[0]);
            /*session_store.user_id=req.body.user_id;*/
            console.log(session_store.user_id);
            res.render('admin/dashbord', {
                title: 'Dashboard',
                session: session_store.user_id
              })
          }
          else
          { 
             console.log('Wrong email address or password. Try again.');
            req.flash('msg_error', "Wrong email address or password. Try again."); 
            res.locals.messages = req.flash();
            //errors=errors.msg = 'Wrong email address or password. Try again.';
            res.render('admin/login',{
              title:"Login Page Valid",
              msg_error:'',
              msg:'Wrong email id or password!.',
              user_id:user_id,
              password:password
            });

           }
        }
      });
    });
  } else {
     console.log(errors);
     res.render("admin/login",{
      title:"Login Page",
      msg_error:errors,
      msg:'',
      user_id:(user_id)?user_id:'',
      password:(password)?password:''
     });
  }
}
 });
//********** Login END.........................
//############ Admin Dashboard .................
app.get('/dashbord', function(req, res){
  session_store=req.session;
  if(!session_store){
      res.redirect('/admin/login');
  }else{
    res.render('admin/dashbord',{
      title:'Dashboard',
      session: session_store.user_id
    });
      
   }
});
// ############ Home page .....................
app.get('/product_list', function(req,res){
  if(session_store){
  req.getConnection(function(error, conn) {
        conn.query('SELECT * FROM products ORDER BY id DESC',function(err, rows){
         if(err){
            throw err;
         }else{
             // render to views/user/list.ejs template file
                res.render('admin/product_list', {
                    title: 'Product List', 
                    data: rows
                });
           }
    });
         
    });
  }else{
    res.redirect('/admin/login');
  }
});
// ############ User Rols page .....................
app.get('/user_rols', function(req,res){
  if(session_store){
  req.getConnection(function(error, conn) {
        conn.query('SELECT * FROM users ORDER BY id DESC',function(err, rows){
         if(err){
            throw err;
         }else{
             // render to views/user/list.ejs template file
                res.render('admin/user_rols', {
                    title: 'User Rols', 
                    data: rows
                });
           }
    });
         
    });
  }else{
    res.redirect('/admin/login');
  }
});
//############  GET Add Product Form.....................
app.get('/add_product', function(req, res){
  if(session_store){
   res.render('admin/add_product',{
   	       title:'Add Product',
   	       p_title:'',
   	       p_disc:'',
   	       p_catg:'',
   	       p_id:'',
   	       p_price:'',
   	       p_image:'',
   	       p_link:''
    });
  }else{
    res.redirect('/admin/login');
  }
});
//################ Add Product Using post methode................
app.post('/add_product', function(req, res){
  if(session_store){
         req.assert('p_title', 'Title is required').notEmpty()  //Validate name
         req.assert('p_disc', 'Discription is required').notEmpty()   //Validate email
         req.assert('p_catg', 'Product Catgogary is required').notEmpty()//Validate email
         req.assert('p_id', 'Product id is required').notEmpty()   //Validate password
         req.assert('p_price', 'Product price is required').notEmpty()  //Validate name
         req.assert('p_image', 'Product Image is required').notEmpty()  //Validate name
         req.assert('p_link', 'Link is required').notEmpty()  //Validate name
    var errors = req.validationErrors()
    
 if( !errors ) {
   
     var product ={
               p_title:req.sanitize('p_title').escape().trim(),
               p_disc:req.sanitize('p_disc').escape().trim(),
               p_catg:req.sanitize('p_catg').escape().trim(),
               p_id:req.sanitize('p_id').escape().trim(),
               p_price:req.sanitize('p_price').escape().trim(),
               p_image:req.sanitize('p_image').escape().trim(),
               p_link:req.sanitize('p_link').escape().trim()
             }
    
     console.log(product);
     req.getConnection(function(error, conn) {
            conn.query('INSERT INTO products SET ?', product, function(err, result) {
                //if(err) throw err
           if (err){ 
                     // render to views/user/add_users.ejs
                     res.render('admin/add_product',{title:'add_product'});
                     console.log('Opps Somthing Went Wrong, User not created!!!!');
                    } 
                else{     
                     // redirect to views/user/list_users.ejs
                      res.redirect('/admin/product_list');
                      console.log('success', 'Add Product successfully!');
                    }           
            });  
        });
    }else{
    	  //Display errors to user
         var error_msg = ''
         errors.forEach(function(error) {
            error_msg += error.msg + '<br>'
         })                
         req.flash('error', error_msg)        
        
         /**
         * Using req.body.name 
         * because req.param('name') is deprecated
         */ 
         // render to views/user/add_users.ejs
         res.render('admin/add_product',{
         	 title:'Add Product',
             p_title:req.body.p_title,
             p_disc:req.body.p_disc,
             p_catg:req.body.p_catg,
             p_id:req.body.p_id,
             p_price:req.body.p_price, 
             p_link:req.body.p_link,
             p_image:req.body.p_image,
           });
        }
  }else{
      res.redirect('/admin/login');
   }
});
//############## Add product END..........................

//############## SHOW EDIT USER FORM...................
app.get('/edit/(:id)', function(req, res, next){
  if(session_store){
    req.getConnection(function(error, conn) {
        conn.query('SELECT * FROM products WHERE id = ' + req.params.id, function(err, rows, fields) {
            if(err){
                throw err;
            } 
            
            // if user not found
            if (rows.length <= 0) {
                /*req.flash('error', 'User not found with id = ' + req.params.id)*/
                console.log('User not found with id ='+ req.params.id);
                res.redirect('/admin/product_list')
            }
            else { // if user found
                // render to views/admin/edit.ejs template file
                res.render('admin/edit_product', {
                    title: 'Edit Product', 
                    //data: rows[0],
                    p_title:rows[0].p_title,
                    p_disc:rows[0].p_disc,
                    p_catg:rows[0].p_catg,
                    p_id:rows[0].p_id,
                    p_price:rows[0].p_price, 
                    p_link:rows[0].p_link,
                    p_image:rows[0].p_image,                     
                });
            }            
        });
    });
  }else{
      res.redirect('/admin/login');
   }
});
//############# Edit END .......................
//############### DELETE USER.............
app.post('/delete/(:id)', function(req, res, next) {
  if(session_store){
    var id = req.params.id;
    req.getConnection(function(error, conn) {
        conn.query('DELETE FROM products WHERE id = ' + id, function(err, result) {
            //if(err) throw err
            if (err) {
                throw err;
                // redirect to users list page
                res.redirect('/admin/product_list')
            } else {
                console.log('success', 'User deleted successfully! id = ' + req.params.id)
                // redirect to users list page
                res.redirect('/admin/product_list')
            }
        });
    });
  }else{
    res.redirect('/admin/login');
  }
});
//################# Delete Product END............

//############# Logout Function......................
app.get('/logout', function(req, res){ 
    req.session.destroy(function(err){ 
     if(err){ 
        console.log(err); 
      } 
     else 
      { 
      console.log(session_store,'<-Session destroy Successfully!!!!!');
      res.redirect('/admin/login'); 
      } 
   }); 
}); 
//############# Logout Function END.....................

module.exports = app;