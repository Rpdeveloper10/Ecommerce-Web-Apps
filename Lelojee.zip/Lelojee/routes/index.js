var express = require('express');
var app = express();

// ############ Home page .....................
app.get('/', function(req,res){
  req.getConnection(function(error, conn) {
        conn.query('SELECT * FROM products ORDER BY id DESC',function(err, rows){
         if(err){
            throw err;
         }else{
             // render to views/user/list.ejs template file
                res.render('users/index', {
                    title: 'Home', 
                    data: rows
                });
           }
    });
         
    });
});
// ############ Electronic's page .....................
app.get('/electronics', function(req,res){
  req.getConnection(function(error, conn) {
        conn.query("SELECT * FROM products WHERE p_catg ='electronics'",function(err, rows){
         if(err){
            throw err;
         }else(rows.length > 0)
            {
             // render to views/user/list.ejs template file
                res.render('users/electronics', {
                    title: 'Electronics', 
                    data: rows
                });
           }
       });
   });
});
// ############ Electronic's page .....................
app.get('/mens', function(req,res){
  req.getConnection(function(error, conn) {
        conn.query("SELECT * FROM products WHERE p_catg ='mens'",function(err, rows){
         if(err){
            throw err;
         }else(rows.length > 0)
            {
             // render to views/user/list.ejs template file
                res.render('users/mens', {
                    title: 'Men', 
                    data: rows
                });
           }
       });
   });
});
// ############ Electronic's page .....................
app.get('/womens', function(req,res){
  req.getConnection(function(error, conn) {
        conn.query("SELECT * FROM products WHERE p_catg ='womens'",function(err, rows){
         if(err){
            throw err;
         }else(rows.length > 0)
            {
             // render to views/user/list.ejs template file
                res.render('users/womens', {
                    title: 'women', 
                    data: rows
                });
           }
       });
   });
});

//********** Get Login Form ..............................
app.get('/login', function(req, res){
  req.flash('msg_error',  ""); 
    if(!req.session.email) {
     res.render("users/login",{
      title:"Login Page",
      msg_error:'',
      msg:'',
      user_id:'',
      password:''
     });
   }else{
   //res.redirect(301, '/');
   res.render("users/login",{
    title:"Login Page",
    msg_error:'',
    msg:'',
    user_id:'',
    password:''
  });
  }
});

//########## Get Form For Create New User .....................
app.get('/create_user', function(req, res){ 
  // render to views/admin/create_user.ejs
   res.render('users/create_user',{
      title:'Create New User',
      name: '',
      email: '',
      mobile:'',
      user_id: '',
      password:'' 
    });
});

//############ Create New user using Post method  .................
app.post('/create_user', function(req, res){
  req.assert('name', 'Name is required').notEmpty()  //Validate name
    req.assert('email', 'Email is required').isEmail()   //Validate email
    req.assert('user_id', 'A valid user_id is required').notEmpty()//Validate user id
    req.assert('password', 'Password is required').notEmpty()   //Validate password
    
    var errors = req.validationErrors()
    
    if( !errors ) {
   
     var user ={
               name:req.sanitize('name').escape().trim(),
               email:req.sanitize('email').escape().trim(),
               user_id:req.sanitize('user_id').escape().trim(),
               password:req.sanitize('password').escape().trim()
               }
      console.log(user);
      req.getConnection(function(error, conn) {
            conn.query('INSERT INTO customer SET ?', user, function(err, result) {
                //if(err) throw err
           if (err){ 
                     req.flash('error', err)
                     // render to views/user/add_users.ejs
                     res.render('/create_user',{
                      title:'Create New user',
                        name: user.name,
                        email: user.email,
                        user_id: user.user_id,
                        password: user.password   
                    });
                     console.log('Opps Somthing Went Worng, User not created!!!!');
                    } 
                else{                
                      console.log('success', 'New User Created successfully!');
                      // redirect to views/user/list_users.ejs
                      res.render('/login',{
                        title:'Login',
                        user_id: user.user_id,
                        password: user.password   
                       });
                    }           
            });  
        });
    }else {   
        //Display errors to user
        var error_msg = ''
        errors.forEach(function(error) {
            error_msg += error.msg + '<br>'
        })                
        req.flash('error', error_msg)        
        
        /**
         * Using req.body.name 
         * because req.param('name') is deprecated
         */ 
       // render to views/user/add_users.ejs
        res.render('admin/create_user',{
           title:'Create New user',
             name:req.body.name,
             email:req.body.email,
             user_id:req.body.user_id,
             password:req.body.password   
        })
    }
});
//########### Create New User END.............................

//########## About Page.............................
app.get('/about', function(req, res){
 res.render('users/about',{
 	title:'About Us'
 });
});

//############ Contact page........................
app.get('/contact', function(req, res){
 res.render('users/contact',{
 	title:'Contact Us'
 });
});

//############ Search page........................
app.post('/search', function(req, res){
    var p_title = req.body.product;
   req.getConnection(function(err, conn){
   conn.query("SELECT * FROM products WHERE p_title LIKE '%"+p_title+"%'", function(err, rows) {
            if(err){
                throw err;
                req.redirect('/');
            } 
            // if user not found
            if (rows.length > 0) {
               // render to views/user/edit.ejs template file
               console.log('search product success');
                res.render('users/search_product', {
                    title: 'Search product', 
                    data: rows                   
                });
            }
        });         
   });
});
//############# Search page END........................
module.exports = app;